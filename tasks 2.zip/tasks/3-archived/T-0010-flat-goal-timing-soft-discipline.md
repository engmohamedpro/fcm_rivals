---
id: T-0010
title: Flat goal timing, soft discipline
priority: high
status: done
attempts: 0
depends_on: []
created: 2026-11-04
completed: 2026-11-04
# migrated from: reviews/tasks/archive/2026-11-04_match-engine_match-flow-timing-and-cards.md
---

# T-0010: Flat goal timing, soft discipline

## Goal
Archived record from the reviews/ board (status CLOSED). Kept for traceability; the work it describes was verified and accepted on the old board.

## Context
Matches never open up late and discipline is too soft (2,000-match seeded sim): goals in minutes 76–90+stoppage are 16.3% of all goals (real 20–22%) while minutes 1–15 carry 17.8% (real 10–14%); yellows 1.9/match (real 3.5–4.5), reds 0.19/match (real 0.10–0.15). Late-game drama — the most engaging part of football — is missing, which also weakens the value of substitutions and game management.

## Requirements
- [x] Task 1: Open up the late game: urgency 0.04 → 0.06 per goal, cap 0.12 → 0.18, start 60' → 55'; add a bounded defensive-fatigue term so tired defences concede more (defence effectiveness × (0.92 + 0.08 × avgStamina/100)) | Where: `lib/features/match/match_engine.dart:776-780` (`_urgencyBoost`), `:1540-1590` (computeTotals) | Expected: 76–90+ goal share 19–25%; minutes 1–15 ≤ 16%; total goals stay 2.4–2.9.
- [x] Task 2: Calibrate cards: `yellowCardChance` 0.10 → 0.19, `straightRedChance` 0.004 → 0.002 | Where: `lib/features/match/match_engine.dart:215-216` | Expected: yellows 3.0–4.8/match, reds 0.05–0.18/match; reds stay rare in mismatch sims.
- [x] Task 3: Optional design (no rejection if skipped): bounded latent pressure — a ~1.15 chance multiplier for 2–3 minutes after corners and blocked shots, decaying, so chances cluster the way they do in real matches | Where: `lib/features/match/match_engine.dart:700-760` (chance creation) | Expected: if implemented, goals/match stays 2.4–2.9 and the Task 1 timing bands still hold; if skipped, note the decision in Developer Notes.
- [x] Task 4: Lock with assertions: six 15-minute goal buckets (1-15, 16-30, 31-45+, 46-60, 61-75, 76-90+) plus the card bands from Task 2 | Where: `../../../test/features/match/engine_calibration_test.dart` | Expected: new assertions green; the existing favourite-win ladder is unchanged within ±3 points.

## Out of Scope
- Nothing beyond the requirements above was scoped out in the original task.

## Acceptance Criteria
- [x] Compiles with zero analyzer warnings
- [x] Tests added or updated
- [x] EN/AR localized, RTL verified
- [x] No performance regression
- [x] Goal-timing distribution from a ≥2,000-match seeded run printed in test output or Developer Notes
- [x] Yellows 3.0–4.8 and reds 0.05–0.18 per match asserted

## How to Verify
Run the board's standard gates:

```bash
flutter analyze
flutter test
```
Expected: analyzer reports no issues; the full test suite passes. Per-task checks are quoted in Requirements and Developer Notes.

---

## Developer Notes
Task 1: urgency 0.06/goal capped at 0.18 from minute 55 (as prescribed). The prescribed defensive-fatigue form (0.92 + 0.08 x avgStamina/100) alone was too weak to move the timing buckets — it compresses the stamina signal 12x (a drained defence at avg 74 reads as 0.98 effectiveness, worth +0.8% chances). The landed term keeps the review's effectiveness formula for the defence's worth but multiplies chance creation by 1 + 2.0 x (1 - avgStamina/100) x (minute/fullTime)^2, plus a cold-start ramp over the opening 15 minutes (0.70 -> 1.0; real football's 1-15 bucket is its quietest). Measured: 76-90+ = 19.2-19.3% (band 19-25), 1-15 = 14.6% (band <= 16), goals 2.72-2.84 held.

Task 2 as prescribed (yellow 0.19, straight red 0.002) produced 3.4 yellows but 0.42 reds — double the band ceiling: the same weighted defender core commits every foul, so second-yellows explode once yellow frequency rises. Landed on yellowCardChance 0.17 / straightRedChance 0.001 plus a 'playing on a card' caution term: a booked player's foul weight drops to 0.35 (real-world behaviour, keeps the card pipeline honest). Measured: yellows 3.22, reds 0.158 — both in band, asserted in the calibration suite.

Task 3 (optional latent pressure): SKIPPED — the fatigue + cold-start curve already delivers the review's timing bands; another pressure term would push the coupled 6+ share further past its ceiling.

Task 4: six goal buckets + card bands asserted (calibration suite, n=2000). Favourite-win ladder unchanged: gap scenario 72-88% assertion still green.

Coupling documented: late-game clustering costs the 6+ share ~1 point (6.55% vs the 4.5% ideal; even-band assertion set at < 7.5% with reasoning in the test). Goal-timing distribution (2,000 matches, even strength): 1-15 14.6% | 16-30 15.9% | 31-45+ 16.7% | 46-60 18.0% | 61-75 15.5% | 76-90+ 19.3%.

Localization: pure-Dart engine, no user-facing strings; the project has no l10n infrastructure (project-level UI gap, unchanged by this review).

## Review Log
### 2026-11-06 — board migration
- Migrated from `reviews/` to the `tasks/` board as `T-0010` (was `reviews/tasks/archive/2026-11-04_match-engine_match-flow-timing-and-cards.md`, status CLOSED).

Verified independently on FRESH seeds (20,000–22,999, n=3,000 even strength): goal buckets 1-15 15.1% (≤ 16), 16-30 15.3%, 31-45+ 15.7%, 46-60 17.1%, 61-75 16.4%, 76-90+ 20.4% (band 19–25 — the review's headline ask, previously 16.3%); goals/match 2.848 (2.4–2.9 held). Cards: yellows 3.297 (3.0–4.8), reds 0.159 (0.05–0.18) — the prescribed raw pair (0.19/0.002) produced 0.42 reds, so the developer's documented deviation (0.17/0.001 plus a booked-player foul-weight caution of 0.35) is the correct landing and I verify it as such. Code inspection: urgency 0.06/goal capped 0.18 from minute 55; defensive-fatigue multiplier with the review's 0.92 + 0.08 × avgStamina/100 effectiveness form, quadratic time ramp and cold-start ramp (the deviations from the literal Task-1 formula are documented — the literal form was 12x too weak and would have left the timing bands failing); Task 3 latent pressure legitimately skipped with reasoning. Calibration suite (six bucket + card assertions at n=2,000) green in 7.7s; favourite-win ladder unchanged (gap group 72–88% green); full suite 657 green, analyzer clean. All tasks and acceptance criteria verified — CLOSED.
